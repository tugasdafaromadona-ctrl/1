import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../cart.dart';
import '../models/product_model.dart';
import '../models/user_model.dart';
import 'dummy_products.dart';

/// Penyimpanan ringan berbasis SharedPreferences agar aplikasi bisa berjalan
/// di Chrome maupun desktop tanpa plugin SQLite native.
///
/// Data yang disimpan: pengguna (admin & pelanggan), produk (termasuk stok),
/// keranjang per pelanggan, dan pesanan.
class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  static const _usersKey = 'stepup_users';
  static const _productsKey = 'stepup_products';
  static const _ordersKey = 'stepup_orders';
  static const _cartsKey = 'stepup_carts';
  bool _initialized = false;

  /// Antrean sederhana supaya operasi baca-ubah-tulis tidak saling menimpa.
  Future<void> _tail = Future.value();

  Future<T> _synchronized<T>(Future<T> Function() action) {
    final completer = Completer<T>();
    final previous = _tail;
    _tail = completer.future.then((_) {}, onError: (_) {});
    previous.then((_) async {
      try {
        completer.complete(await action());
      } catch (e, s) {
        completer.completeError(e, s);
      }
    });
    return completer.future;
  }

  @visibleForTesting
  void resetForTest() => _initialized = false;

  Future<void> get database async => _init();

  Future<void> _init() async {
    if (_initialized) return;
    final prefs = await SharedPreferences.getInstance();

    if (!prefs.containsKey(_usersKey)) {
      await prefs.setString(
          _usersKey,
          jsonEncode([
            {'id': 1, 'username': 'admin', 'password': 'admin123', 'role': 'admin'}
          ]));
    }
    if (!prefs.containsKey(_productsKey)) {
      await prefs.setString(_productsKey,
          jsonEncode(dummyProducts.map((p) => p.toMap()).toList()));
    }
    if (!prefs.containsKey(_ordersKey)) {
      await prefs.setString(_ordersKey, jsonEncode(<Map<String, dynamic>>[]));
    }
    if (!prefs.containsKey(_cartsKey)) {
      await prefs.setString(_cartsKey, jsonEncode(<String, dynamic>{}));
    }
    _initialized = true;
  }

  Future<SharedPreferences> _prefs() async {
    await _init();
    final prefs = await SharedPreferences.getInstance();
    // Ambil data terbaru (misalnya jika admin & pelanggan dibuka di tab berbeda).
    await prefs.reload();
    return prefs;
  }

  Future<List<Map<String, dynamic>>> _readList(String key) async {
    final prefs = await _prefs();
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return <Map<String, dynamic>>[];
    return (jsonDecode(raw) as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  Future<void> _writeList(String key, List<Map<String, dynamic>> values) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(values));
  }

  /// Keranjang disimpan sebagai { "<userId>": [ {product_id, size, quantity} ] }.
  Future<Map<String, List<Map<String, dynamic>>>> _readCarts() async {
    final prefs = await _prefs();
    final raw = prefs.getString(_cartsKey);
    if (raw == null || raw.isEmpty) return {};
    final decoded = jsonDecode(raw) as Map;
    return decoded.map((k, v) => MapEntry(
          k.toString(),
          (v as List).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
        ));
  }

  Future<void> _writeCarts(Map<String, List<Map<String, dynamic>>> carts) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_cartsKey, jsonEncode(carts));
  }

  int _int(dynamic v) => (v as num?)?.toInt() ?? 0;

  // ───────────────────────── Pengguna ─────────────────────────

  Future<UserModel?> login(String username, String password) async {
    final users = await _readList(_usersKey);
    final matches = users.where((u) =>
        (u['username'] as String).trim().toLowerCase() ==
            username.trim().toLowerCase() &&
        (u['password'] as String) == password.trim());
    return matches.isEmpty ? null : UserModel.fromMap(matches.first);
  }

  /// Mendaftarkan pengguna baru. [role] = 'customer' atau 'admin'.
  /// Mengembalikan false jika username sudah dipakai.
  Future<bool> register(String username, String password,
      {String role = 'customer'}) {
    return _synchronized(() async {
      final users = await _readList(_usersKey);
      if (users.any((u) =>
          (u['username'] as String).toLowerCase() ==
          username.trim().toLowerCase())) {
        return false;
      }
      final nextId = users.fold<int>(0, (m, u) => _int(u['id']) > m ? _int(u['id']) : m) + 1;
      users.add({
        'id': nextId,
        'username': username.trim(),
        'password': password.trim(),
        'role': role == 'admin' ? 'admin' : 'customer',
      });
      await _writeList(_usersKey, users);
      return true;
    });
  }

  // ───────────────────────── Produk ─────────────────────────

  Future<List<ProductModel>> getProducts(
      {String query = '', String category = 'Semua'}) async {
    final products =
        (await _readList(_productsKey)).map(ProductModel.fromMap).where((p) {
      final q = query.trim().toLowerCase();
      final matchesQuery = q.isEmpty ||
          p.name.toLowerCase().contains(q) ||
          p.brand.toLowerCase().contains(q);
      final matchesCategory = category == 'Semua' || p.category == category;
      return matchesQuery && matchesCategory;
    }).toList();
    products.sort((a, b) => a.name.compareTo(b.name));
    return products;
  }

  Future<ProductModel?> getProduct(String id) async {
    final rows = await _readList(_productsKey);
    final i = rows.indexWhere((r) => r['id'].toString() == id);
    return i < 0 ? null : ProductModel.fromMap(rows[i]);
  }

  /// Tambah produk baru atau perbarui produk yang sudah ada.
  Future<void> saveProduct(ProductModel p) {
    return _synchronized(() async {
      final rows = await _readList(_productsKey);
      final index = rows.indexWhere((r) => r['id'].toString() == p.id);
      if (index < 0) {
        rows.add(p.toMap());
      } else {
        rows[index] = p.toMap();
      }
      await _writeList(_productsKey, rows);
    });
  }

  /// Admin: set stok barang lama ke nilai tertentu.
  Future<void> updateStock(String id, int stock) {
    return _synchronized(() async {
      final rows = await _readList(_productsKey);
      final index = rows.indexWhere((r) => r['id'].toString() == id);
      if (index < 0) return;
      rows[index]['stock'] = stock < 0 ? 0 : stock;
      await _writeList(_productsKey, rows);
    });
  }

  Future<void> deleteProduct(String id) {
    return _synchronized(() async {
      final rows = await _readList(_productsKey);
      rows.removeWhere((r) => r['id'].toString() == id);
      await _writeList(_productsKey, rows);
    });
  }

  // ───────────────────────── Keranjang ─────────────────────────

  /// Isi keranjang milik [userId] lengkap dengan data produk (stok terbaru).
  Future<List<CartItem>> getCart(int userId) async {
    final carts = await _readCarts();
    final lines = carts[userId.toString()] ?? [];
    final products = await _readList(_productsKey);
    final result = <CartItem>[];
    for (final line in lines) {
      final i = products.indexWhere(
          (p) => p['id'].toString() == line['product_id'].toString());
      if (i < 0) continue; // produk sudah dihapus admin
      result.add(CartItem(ProductModel.fromMap(products[i]),
          _int(line['size']), _int(line['quantity'])));
    }
    return result;
  }

  int _lineIndex(List<Map<String, dynamic>> lines, String productId, int size) =>
      lines.indexWhere((l) =>
          l['product_id'].toString() == productId && _int(l['size']) == size);

  /// Masukkan 1 barang ke keranjang (atau tambah jumlahnya) dan KURANGI stok.
  /// false jika stok habis / produk tidak ada.
  Future<bool> addToCart(int userId, String productId, int size) {
    return _synchronized(() async {
      final products = await _readList(_productsKey);
      final pi = products.indexWhere((p) => p['id'].toString() == productId);
      if (pi < 0) return false;
      final stock = _int(products[pi]['stock']);
      if (stock <= 0) return false;

      final carts = await _readCarts();
      final lines = carts[userId.toString()] ?? [];
      final li = _lineIndex(lines, productId, size);
      if (li >= 0) {
        lines[li]['quantity'] = _int(lines[li]['quantity']) + 1;
      } else {
        lines.add({'product_id': productId, 'size': size, 'quantity': 1});
      }
      carts[userId.toString()] = lines;
      products[pi]['stock'] = stock - 1;

      await _writeList(_productsKey, products);
      await _writeCarts(carts);
      return true;
    });
  }

  /// Kurangi jumlah 1 barang di keranjang dan KEMBALIKAN 1 stok.
  /// Jika jumlah menjadi 0, barang dihapus dari keranjang.
  Future<void> decreaseInCart(int userId, String productId, int size) {
    return _synchronized(() async {
      final carts = await _readCarts();
      final lines = carts[userId.toString()] ?? [];
      final li = _lineIndex(lines, productId, size);
      if (li < 0) return;

      final qty = _int(lines[li]['quantity']);
      if (qty <= 1) {
        lines.removeAt(li);
      } else {
        lines[li]['quantity'] = qty - 1;
      }
      carts[userId.toString()] = lines;

      final products = await _readList(_productsKey);
      final pi = products.indexWhere((p) => p['id'].toString() == productId);
      if (pi >= 0) {
        products[pi]['stock'] = _int(products[pi]['stock']) + 1;
        await _writeList(_productsKey, products);
      }
      await _writeCarts(carts);
    });
  }

  /// Hapus satu baris barang dari keranjang dan KEMBALIKAN seluruh stoknya.
  Future<void> removeFromCart(int userId, String productId, int size) {
    return _synchronized(() async {
      final carts = await _readCarts();
      final lines = carts[userId.toString()] ?? [];
      final li = _lineIndex(lines, productId, size);
      if (li < 0) return;

      final qty = _int(lines[li]['quantity']);
      lines.removeAt(li);
      carts[userId.toString()] = lines;

      final products = await _readList(_productsKey);
      final pi = products.indexWhere((p) => p['id'].toString() == productId);
      if (pi >= 0) {
        products[pi]['stock'] = _int(products[pi]['stock']) + qty;
        await _writeList(_productsKey, products);
      }
      await _writeCarts(carts);
    });
  }

  // ───────────────────────── Pesanan ─────────────────────────

  /// Checkout: ubah isi keranjang menjadi pesanan lalu kosongkan keranjang.
  /// Stok sudah dikurangi saat barang masuk keranjang, jadi tidak dikurangi lagi.
  /// Mengembalikan id pesanan, atau null jika keranjang kosong.
  Future<int?> checkoutCart(int userId, String customerName) {
    return _synchronized(() async {
      final carts = await _readCarts();
      final lines = carts[userId.toString()] ?? [];
      if (lines.isEmpty) return null;

      final products = await _readList(_productsKey);
      final orderItems = <Map<String, dynamic>>[];
      double total = 0;
      for (final line in lines) {
        final pi = products.indexWhere(
            (p) => p['id'].toString() == line['product_id'].toString());
        if (pi < 0) continue;
        final price = (products[pi]['price'] as num?)?.toDouble() ?? 0;
        final qty = _int(line['quantity']);
        total += price * qty;
        orderItems.add({
          'product_name': products[pi]['name'],
          'size': line['size'],
          'quantity': qty,
          'subtotal': price * qty,
        });
      }
      if (orderItems.isEmpty) {
        carts[userId.toString()] = [];
        await _writeCarts(carts);
        return null;
      }

      final orders = await _readList(_ordersKey);
      final nextId = orders.fold<int>(0, (m, o) => _int(o['id']) > m ? _int(o['id']) : m) + 1;
      orders.add({
        'id': nextId,
        'customer_name': customerName,
        'total_amount': total,
        'order_date': DateTime.now().toIso8601String(),
        'status': 'Diproses',
        'items': orderItems,
      });
      carts[userId.toString()] = [];
      await _writeList(_ordersKey, orders);
      await _writeCarts(carts);
      return nextId;
    });
  }

  Future<List<Map<String, dynamic>>> getOrdersWithItems() async {
    return _readList(_ordersKey);
  }

  Future<void> updateOrderStatus(int id, String status) {
    return _synchronized(() async {
      final orders = await _readList(_ordersKey);
      final index = orders.indexWhere((o) => _int(o['id']) == id);
      if (index >= 0) {
        orders[index]['status'] = status;
        await _writeList(_ordersKey, orders);
      }
    });
  }
}
