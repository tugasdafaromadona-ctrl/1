import '../models/product_model.dart';

const List<ProductModel> dummyProducts = [
  ProductModel(
      id: 'p1', name: 'Velocity Runner', brand: 'StepUp', category: 'Lari',
      price: 899000, stock: 20,
      description: 'Sneaker lari ringan dengan sol responsif untuk pace cepat.'),
  ProductModel(
      id: 'p2', name: 'Urban Drift', brand: 'StepUp', category: 'Kasual',
      price: 749000, stock: 25,
      description: 'Gaya jalanan minimalis, nyaman dipakai seharian.'),
  ProductModel(
      id: 'p3', name: 'Court King', brand: 'Hoopz', category: 'Basket',
      price: 1299000, stock: 12,
      description: 'Sepatu basket high-top dengan cengkeraman kuat dan bantalan tebal.'),
  ProductModel(
      id: 'p4', name: 'Cloud Walker', brand: 'Aeris', category: 'Kasual',
      price: 679000, stock: 30,
      description: 'Midsole empuk seperti berjalan di atas awan.'),
  ProductModel(
      id: 'p5', name: 'Trail Blazer', brand: 'Aeris', category: 'Lari',
      price: 1099000, stock: 10,
      description: 'Outsole bergerigi untuk lari lintas alam dan medan licin.'),
  ProductModel(
      id: 'p6', name: 'Night Raven', brand: 'Hoopz', category: 'Basket',
      price: 1149000, stock: 8,
      description: 'Warna gelap elegan dengan aksen biru, stabil saat bermanuver.'),
];
