class UserModel {
  final int id;
  final String username;
  final String password;
  final String role; // admin / customer

  UserModel({
    required this.id,
    required this.username,
    required this.password,
    required this.role,
  });

  bool get isAdmin => role == 'admin';

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
        id: map['id'] is int
            ? map['id'] as int
            : int.tryParse(map['id'].toString()) ?? 0,
        username: map['username'] as String? ?? '',
        password: map['password'] as String? ?? '',
        role: map['role'] as String? ?? 'customer',
      );

  Map<String, dynamic> toMap() =>
      {'id': id, 'username': username, 'password': password, 'role': role};
}
