class ProductModel {
  final String id;
  final String name;
  final String brand;
  final String category; // Lari, Kasual, Basket
  final double price;
  final String description;
  final int stock;

  const ProductModel({
    required this.id,
    required this.name,
    required this.brand,
    required this.category,
    required this.price,
    required this.description,
    required this.stock,
  });

  factory ProductModel.fromMap(Map<String, dynamic> m) => ProductModel(
        id: m['id'].toString(),
        name: m['name'] as String? ?? '',
        brand: m['brand'] as String? ?? '',
        category: m['category'] as String? ?? 'Kasual',
        price: (m['price'] as num?)?.toDouble() ?? 0,
        description: m['description'] as String? ?? '',
        stock: (m['stock'] as num?)?.toInt() ?? 0,
      );

  ProductModel copyWith({int? stock}) => ProductModel(
        id: id,
        name: name,
        brand: brand,
        category: category,
        price: price,
        description: description,
        stock: stock ?? this.stock,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'brand': brand,
        'category': category,
        'price': price,
        'description': description,
        'stock': stock,
      };
}
