import 'package:flutter/foundation.dart';
import 'datasources/database_helper.dart';
import 'models/product_model.dart';

class CartItem {
  ProductModel product;
  final int size;
  int quantity;
  CartItem(this.product, this.size, this.quantity);
  double get subtotal => product.price * quantity;
}

/// Keranjang milik pelanggan yang sedang login.
///
/// Isi keranjang disimpan di database lokal per pelanggan. Setiap barang
/// yang masuk/ditambah akan MENGURANGI stok produk, dan setiap barang yang
/// dikurangi/dihapus akan MENGEMBALIKAN stoknya.
class Cart extends ChangeNotifier {
  Cart._();
  static final Cart instance = Cart._();

  int? _userId;
  final List<CartItem> items = [];

  bool get isActive => _userId != null;
  int get count => items.fold(0, (s, i) => s + i.quantity);
  double get total => items.fold(0.0, (s, i) => s + i.subtotal);

  /// Muat keranjang tersimpan milik pelanggan [userId] (dipanggil saat login).
  Future<void> load(int userId) async {
    _userId = userId;
    await _refresh();
  }

  /// Kosongkan tampilan keranjang saat logout. Isi keranjang tetap tersimpan
  /// di database (stoknya tetap tercadangkan untuk pelanggan tersebut).
  void reset() {
    _userId = null;
    items.clear();
    notifyListeners();
  }

  Future<void> _refresh() async {
    final id = _userId;
    final fresh = id == null
        ? <CartItem>[]
        : await DatabaseHelper.instance.getCart(id);
    items
      ..clear()
      ..addAll(fresh);
    notifyListeners();
  }

  /// Tambah 1 barang (atau tambah jumlahnya). Mengembalikan pesan error,
  /// atau null jika berhasil.
  Future<String?> add(ProductModel p, int size) async {
    final id = _userId;
    if (id == null) return 'Silakan login sebagai pelanggan dulu';
    final ok = await DatabaseHelper.instance.addToCart(id, p.id, size);
    await _refresh();
    return ok ? null : 'Stok ${p.name} sudah habis';
  }

  /// Kurangi jumlah 1 (jika tinggal 1, barang dihapus dari keranjang).
  Future<void> decrease(CartItem item) async {
    final id = _userId;
    if (id == null) return;
    await DatabaseHelper.instance.decreaseInCart(id, item.product.id, item.size);
    await _refresh();
  }

  /// Hapus barang dari keranjang.
  Future<void> remove(CartItem item) async {
    final id = _userId;
    if (id == null) return;
    await DatabaseHelper.instance.removeFromCart(id, item.product.id, item.size);
    await _refresh();
  }

  /// Checkout. Mengembalikan id pesanan atau null jika keranjang kosong.
  Future<int?> checkout(String customerName) async {
    final id = _userId;
    if (id == null) return null;
    final orderId = await DatabaseHelper.instance.checkoutCart(id, customerName);
    await _refresh();
    return orderId;
  }
}
