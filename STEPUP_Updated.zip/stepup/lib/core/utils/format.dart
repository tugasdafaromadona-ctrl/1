import 'package:intl/intl.dart';

String rupiah(num v) =>
    NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0)
        .format(v);
