import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF2F80FF);
  static const dark = Color(0xFF0B0E14);
  static const surface = Color(0xFF151A23);
  static const card = Color(0xFF1B212C);
  static const textPrimary = Color(0xFFF2F5FA);
  static const textSecondary = Color(0xFF9AA4B5);
  static const danger = Color(0xFFFF5252);
  static const success = Color(0xFF2ECC71);
  static const gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF0B0E14), Color(0xFF12305E)],
  );
}
