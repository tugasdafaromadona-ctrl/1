import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/format.dart';
import '../../data/cart.dart';
import '../../data/datasources/database_helper.dart';
import '../../data/models/product_model.dart';
import 'catalog_screen.dart' show ProductThumb;

class ProductDetailScreen extends StatefulWidget {
  final ProductModel product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  static const sizes = [38, 39, 40, 41, 42, 43, 44];
  int? _size;
  late ProductModel _product = widget.product;

  @override
  void initState() {
    super.initState();
    _refreshProduct();
  }

  /// Ambil stok terbaru dari database.
  Future<void> _refreshProduct() async {
    final fresh = await DatabaseHelper.instance.getProduct(widget.product.id);
    if (!mounted || fresh == null) return;
    setState(() => _product = fresh);
  }

  Future<void> _addToCart() async {
    final p = _product;
    String msg;
    if (_size == null) {
      msg = 'Pilih ukuran dulu ya';
    } else {
      final err = await Cart.instance.add(p, _size!);
      msg = err ?? '${p.name} (size $_size) ditambahkan ke keranjang';
      await _refreshProduct();
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = _product;
    return Scaffold(
      appBar: AppBar(title: Text(p.name)),
      body: ListView(
        children: [
          SizedBox(height: 260, child: ProductThumb(p, iconSize: 110)),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.brand.toUpperCase(),
                    style: const TextStyle(
                        color: AppColors.primary, letterSpacing: 1.5)),
                const SizedBox(height: 4),
                Text(p.name,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Text(rupiah(p.price),
                        style: const TextStyle(
                            fontSize: 20,
                            color: AppColors.primary,
                            fontWeight: FontWeight.bold)),
                    const Spacer(),
                    Text(p.stock > 0 ? 'Stok: ${p.stock}' : 'Stok habis',
                        style: TextStyle(
                            color: p.stock > 0
                                ? AppColors.textSecondary
                                : AppColors.danger)),
                  ],
                ),
                const SizedBox(height: 18),
                const Text('Pilih Ukuran (EU)',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final s in sizes)
                      ChoiceChip(
                        label: Text('$s'),
                        selected: _size == s,
                        selectedColor: AppColors.primary,
                        onSelected: (_) => setState(() => _size = s),
                      ),
                  ],
                ),
                const SizedBox(height: 18),
                const Text('Deskripsi',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(p.description,
                    style: const TextStyle(color: AppColors.textSecondary)),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.add_shopping_cart),
                    label: const Text('Tambah ke Keranjang'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: p.stock <= 0 ? null : _addToCart,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
