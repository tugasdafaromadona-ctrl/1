import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/format.dart';
import '../../data/datasources/database_helper.dart';
import '../../data/models/product_model.dart';
import '../../providers/auth_provider.dart';
import 'catalog_screen.dart' show categories, categoryIcon;
import 'login_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  List<ProductModel> _products = [];
  List<Map<String, dynamic>> _orders = [];

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final p = await DatabaseHelper.instance.getProducts();
    final o = await DatabaseHelper.instance.getOrdersWithItems();
    if (!mounted) return;
    setState(() {
      _products = p;
      _orders = o;
    });
  }

  void _logout() {
    context.read<AuthProvider>().logout();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  Future<void> _openForm([ProductModel? edit]) async {
    final result = await showModalBottomSheet<ProductModel>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      builder: (_) => _ProductForm(product: edit),
    );
    if (result == null) return;
    await DatabaseHelper.instance.saveProduct(result);
    _reload();
  }

  Future<void> _editStock(ProductModel p) async {
    final newStock = await showDialog<int>(
      context: context,
      builder: (_) => _StockDialog(product: p),
    );
    if (newStock == null) return;
    await DatabaseHelper.instance.updateStock(p.id, newStock);
    _reload();
  }

  Future<void> _delete(ProductModel p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus produk?'),
        content: Text('${p.name} akan dihapus dari katalog.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Hapus',
                  style: TextStyle(color: AppColors.danger))),
        ],
      ),
    );
    if (ok != true) return;
    await DatabaseHelper.instance.deleteProduct(p.id);
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final revenue = _orders.fold<double>(
        0, (s, o) => s + ((o['total_amount'] as num?)?.toDouble() ?? 0));
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Admin • StepUp',
              style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
                icon: const Icon(Icons.refresh),
                tooltip: 'Muat ulang (lihat stok terbaru)',
                onPressed: _reload),
            IconButton(
                icon: const Icon(Icons.logout),
                tooltip: 'Keluar',
                onPressed: _logout),
          ],
          bottom: const TabBar(
            indicatorColor: AppColors.primary,
            tabs: [
              Tab(icon: Icon(Icons.inventory_2_outlined), text: 'Produk'),
              Tab(icon: Icon(Icons.receipt_long_outlined), text: 'Pesanan'),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          onPressed: () => _openForm(),
          icon: const Icon(Icons.add),
          label: const Text('Produk'),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _stat('Produk', '${_products.length}', Icons.checkroom),
                  const SizedBox(width: 10),
                  _stat('Pesanan', '${_orders.length}', Icons.shopping_bag),
                  const SizedBox(width: 10),
                  _stat('Omzet', rupiah(revenue), Icons.payments),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(children: [_productList(), _orderList()]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value, IconData icon) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 18, color: AppColors.primary),
              const SizedBox(height: 6),
              FittedBox(
                child: Text(value,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15)),
              ),
              Text(label,
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 11)),
            ],
          ),
        ),
      );

  Widget _productList() => _products.isEmpty
      ? const Center(child: Text('Belum ada produk'))
      : ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
          itemCount: _products.length,
          itemBuilder: (_, i) {
            final p = _products[i];
            return Card(
              color: AppColors.card,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.primary.withValues(alpha: 0.2),
                  child: Icon(categoryIcon(p.category),
                      color: AppColors.primary),
                ),
                title: Text(p.name,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(
                    '${p.brand} • ${rupiah(p.price)} • stok ${p.stock}',
                    style: TextStyle(
                        color: p.stock == 0 ? AppColors.danger : null)),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                        tooltip: 'Update stok',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.inventory_outlined,
                            color: AppColors.primary),
                        onPressed: () => _editStock(p)),
                    IconButton(
                        tooltip: 'Edit produk',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () => _openForm(p)),
                    IconButton(
                        tooltip: 'Hapus produk',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.delete_outline,
                            color: AppColors.danger),
                        onPressed: () => _delete(p)),
                  ],
                ),
              ),
            );
          },
        );

  Widget _orderList() => _orders.isEmpty
      ? const Center(child: Text('Belum ada pesanan'))
      : ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
          itemCount: _orders.length,
          itemBuilder: (_, i) {
            final o = _orders[i];
            final date = DateTime.tryParse(o['order_date'] as String? ?? '');
            final items = (o['items'] as List).cast<Map<String, dynamic>>();
            return Card(
              color: AppColors.card,
              child: ExpansionTile(
                title: Text('#${o['id']} • ${o['customer_name']}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(
                    '${rupiah(o['total_amount'] as num)} • ${date == null ? '-' : DateFormat('dd/MM/yyyy HH:mm').format(date)}'),
                trailing: PopupMenuButton<String>(
                  tooltip: 'Ubah status',
                  onSelected: (s) async {
                    await DatabaseHelper.instance
                        .updateOrderStatus(o['id'] as int, s);
                    _reload();
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'Diproses', child: Text('Diproses')),
                    PopupMenuItem(value: 'Dikirim', child: Text('Dikirim')),
                    PopupMenuItem(value: 'Selesai', child: Text('Selesai')),
                  ],
                  child: Chip(
                    label: Text('${o['status']}'),
                    backgroundColor: o['status'] == 'Selesai'
                        ? AppColors.success.withValues(alpha: 0.25)
                        : AppColors.primary.withValues(alpha: 0.25),
                  ),
                ),
                children: [
                  for (final it in items)
                    ListTile(
                      dense: true,
                      title: Text('${it['product_name']} (size ${it['size']})'),
                      trailing: Text(
                          '${it['quantity']} x • ${rupiah(it['subtotal'] as num)}'),
                    ),
                ],
              ),
            );
          },
        );
}

/// Dialog kecil untuk memperbarui stok barang yang sudah ada.
class _StockDialog extends StatefulWidget {
  final ProductModel product;
  const _StockDialog({required this.product});

  @override
  State<_StockDialog> createState() => _StockDialogState();
}

class _StockDialogState extends State<_StockDialog> {
  late final _c = TextEditingController(text: widget.product.stock.toString());
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _add(int n) {
    final cur = int.tryParse(_c.text.trim()) ?? 0;
    final next = cur + n < 0 ? 0 : cur + n;
    setState(() {
      _c.text = next.toString();
      _error = null;
    });
  }

  void _save() {
    final v = int.tryParse(_c.text.trim());
    if (v == null || v < 0) {
      setState(() => _error = 'Isi dengan angka 0 atau lebih');
      return;
    }
    Navigator.pop(context, v);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Update stok\n${widget.product.name}',
          style: const TextStyle(fontSize: 16)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _c,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
                labelText: 'Jumlah stok', errorText: _error),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              OutlinedButton(onPressed: () => _add(-1), child: const Text('-1')),
              OutlinedButton(onPressed: () => _add(1), child: const Text('+1')),
              OutlinedButton(onPressed: () => _add(5), child: const Text('+5')),
              OutlinedButton(onPressed: () => _add(10), child: const Text('+10')),
            ],
          ),
        ],
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal')),
        TextButton(onPressed: _save, child: const Text('Simpan')),
      ],
    );
  }
}

class _ProductForm extends StatefulWidget {
  final ProductModel? product;
  const _ProductForm({this.product});

  @override
  State<_ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<_ProductForm> {
  final _key = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.product?.name);
  late final _brand = TextEditingController(text: widget.product?.brand);
  late final _price = TextEditingController(
      text: widget.product == null ? '' : widget.product!.price.toInt().toString());
  late final _stock =
      TextEditingController(text: widget.product?.stock.toString());
  late final _desc = TextEditingController(text: widget.product?.description);
  late String _category = widget.product?.category ?? 'Lari';

  @override
  void dispose() {
    for (final c in [_name, _brand, _price, _stock, _desc]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _req(String? v) => (v ?? '').trim().isEmpty ? 'Wajib diisi' : null;

  String? _num(String? v) =>
      int.tryParse((v ?? '').trim()) == null ? 'Isi dengan angka' : null;

  void _save() {
    if (!_key.currentState!.validate()) return;
    Navigator.pop(
      context,
      ProductModel(
        id: widget.product?.id ??
            'p${DateTime.now().millisecondsSinceEpoch}',
        name: _name.text.trim(),
        brand: _brand.text.trim(),
        category: _category,
        price: double.parse(_price.text.trim()),
        stock: int.parse(_stock.text.trim()),
        description: _desc.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Form(
          key: _key,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(widget.product == null ? 'Tambah Produk' : 'Edit Produk',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              TextFormField(
                  controller: _name,
                  validator: _req,
                  decoration: const InputDecoration(labelText: 'Nama sneaker')),
              TextFormField(
                  controller: _brand,
                  validator: _req,
                  decoration: const InputDecoration(labelText: 'Brand')),
              DropdownButtonFormField<String>(
                initialValue: _category,
                decoration: const InputDecoration(labelText: 'Kategori'),
                items: [
                  for (final c in categories.where((c) => c != 'Semua'))
                    DropdownMenuItem(value: c, child: Text(c)),
                ],
                onChanged: (v) => setState(() => _category = v ?? _category),
              ),
              TextFormField(
                  controller: _price,
                  validator: _num,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Harga (Rp)')),
              TextFormField(
                  controller: _stock,
                  validator: _num,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Stok')),
              TextFormField(
                  controller: _desc,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'Deskripsi')),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text('Simpan'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
