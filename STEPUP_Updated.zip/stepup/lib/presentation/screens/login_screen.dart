import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../providers/auth_provider.dart';
import 'admin_dashboard_screen.dart';
import 'catalog_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _userC = TextEditingController();
  final _passC = TextEditingController();
  final _codeC = TextEditingController();
  String _role = 'customer'; // 'customer' atau 'admin'
  bool _isRegister = false;
  bool _hidePass = true;

  @override
  void dispose() {
    _userC.dispose();
    _passC.dispose();
    _codeC.dispose();
    super.dispose();
  }

  void _toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
      );

  void _goHome() {
    final isAdmin = context.read<AuthProvider>().isAdmin;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) =>
            isAdmin ? const AdminDashboardScreen() : const CatalogScreen(),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final error = _isRegister
        ? await auth.register(_userC.text, _passC.text,
            role: _role, adminCode: _codeC.text)
        : await auth.login(_userC.text, _passC.text, role: _role);
    if (!mounted) return;
    if (error != null) {
      _toast(error);
      return;
    }
    if (_isRegister) {
      _toast(_role == 'admin'
          ? 'Admin berhasil didaftarkan'
          : 'Pelanggan berhasil didaftarkan');
    }
    _goHome();
  }

  void _guest() {
    context.read<AuthProvider>().continueAsGuest();
    _goHome();
  }

  @override
  Widget build(BuildContext context) {
    final loading = context.watch<AuthProvider>().isLoading;
    final isAdminRole = _role == 'admin';
    final roleLabel = isAdminRole ? 'Admin' : 'Pelanggan';
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.gradient),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 380),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset('assets/images/logo.png', width: 150),
                    const SizedBox(height: 20),
                    Text(
                      _isRegister
                          ? 'Daftar $roleLabel'
                          : 'Masuk $roleLabel',
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    const Text('Find your next step.',
                        style: TextStyle(color: AppColors.textSecondary)),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: SegmentedButton<String>(
                        segments: const [
                          ButtonSegment(
                              value: 'customer',
                              label: Text('Pelanggan'),
                              icon: Icon(Icons.person_outline)),
                          ButtonSegment(
                              value: 'admin',
                              label: Text('Admin'),
                              icon: Icon(Icons.admin_panel_settings_outlined)),
                        ],
                        selected: {_role},
                        onSelectionChanged: (v) =>
                            setState(() => _role = v.first),
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextFormField(
                      controller: _userC,
                      validator: (v) => (v ?? '').trim().isEmpty
                          ? 'Username wajib diisi'
                          : null,
                      decoration: _dec('Username', Icons.person_outline),
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _passC,
                      obscureText: _hidePass,
                      validator: (v) {
                        final t = (v ?? '').trim();
                        if (t.isEmpty) return 'Password wajib diisi';
                        if (_isRegister && t.length < 4) {
                          return 'Minimal 4 karakter';
                        }
                        return null;
                      },
                      decoration: _dec('Password', Icons.lock_outline).copyWith(
                        suffixIcon: IconButton(
                          icon: Icon(_hidePass
                              ? Icons.visibility_off
                              : Icons.visibility),
                          onPressed: () =>
                              setState(() => _hidePass = !_hidePass),
                        ),
                      ),
                    ),
                    if (_isRegister && isAdminRole) ...[
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _codeC,
                        validator: (v) => (v ?? '').trim().isEmpty
                            ? 'Kode admin wajib diisi'
                            : null,
                        decoration:
                            _dec('Kode Admin', Icons.vpn_key_outlined),
                      ),
                    ],
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: loading ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: loading
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white))
                            : Text(_isRegister
                                ? 'Daftar sebagai $roleLabel'
                                : 'Masuk sebagai $roleLabel'),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(() => _isRegister = !_isRegister),
                      child: Text(_isRegister
                          ? 'Sudah punya akun? Masuk'
                          : 'Belum punya akun? Daftar'),
                    ),
                    OutlinedButton.icon(
                      onPressed: _guest,
                      icon: const Icon(Icons.storefront_outlined),
                      label: const Text('Lihat katalog sebagai tamu'),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _isRegister && isAdminRole
                          ? 'Kode pendaftaran admin: $adminRegistrationCode'
                          : 'Akun admin demo: admin / admin123',
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _dec(String label, IconData icon) => InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: AppColors.card,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      );
}
