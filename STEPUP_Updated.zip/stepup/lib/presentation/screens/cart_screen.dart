import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/format.dart';
import '../../data/cart.dart';
import '../../providers/auth_provider.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  void _toast(BuildContext context, String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
      );

  Future<void> _checkout(BuildContext context) async {
    final cart = Cart.instance;
    final auth = context.read<AuthProvider>();
    final messenger = ScaffoldMessenger.of(context);
    if (cart.items.isEmpty) return;
    if (!auth.isAuthenticated) {
      messenger.showSnackBar(const SnackBar(
        content: Text('Silakan login dulu untuk checkout'),
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }
    final id = await cart.checkout(auth.user!.username);
    if (!context.mounted) return;
    Navigator.pop(context);
    messenger.showSnackBar(SnackBar(
      content: Text(id == null
          ? 'Keranjang kosong'
          : 'Pesanan #$id berhasil dibuat'),
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Keranjang')),
      body: ListenableBuilder(
        listenable: Cart.instance,
        builder: (context, _) {
          final cart = Cart.instance;
          return Column(
            children: [
              Expanded(
                child: cart.items.isEmpty
                    ? const Center(child: Text('Keranjang masih kosong'))
                    : ListView(
                        padding: const EdgeInsets.all(12),
                        children: [
                          for (final item in cart.items)
                            Card(
                              color: AppColors.card,
                              child: ListTile(
                                leading: const Icon(Icons.directions_run,
                                    color: AppColors.primary),
                                title: Text(
                                    '${item.product.name} • ${item.size}',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold)),
                                subtitle: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(rupiah(item.product.price),
                                        style: const TextStyle(
                                            color: AppColors.primary)),
                                    Text('Sisa stok: ${item.product.stock}',
                                        style: TextStyle(
                                            fontSize: 12,
                                            color: item.product.stock > 0
                                                ? AppColors.textSecondary
                                                : AppColors.danger)),
                                    Row(
                                      children: [
                                        IconButton(
                                          tooltip: 'Kurangi',
                                          icon: const Icon(
                                              Icons.remove_circle_outline),
                                          onPressed: () =>
                                              cart.decrease(item),
                                        ),
                                        Text('${item.quantity}',
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold)),
                                        IconButton(
                                          tooltip: 'Tambah',
                                          icon: const Icon(
                                              Icons.add_circle_outline),
                                          onPressed: item.product.stock <= 0
                                              ? null
                                              : () async {
                                                  final err = await cart.add(
                                                      item.product,
                                                      item.size);
                                                  if (err != null &&
                                                      context.mounted) {
                                                    _toast(context, err);
                                                  }
                                                },
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                isThreeLine: true,
                                trailing: IconButton(
                                  tooltip: 'Hapus',
                                  icon: const Icon(Icons.delete,
                                      color: AppColors.danger),
                                  onPressed: () => cart.remove(item),
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
              Container(
                color: AppColors.surface,
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Total',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        Text(rupiah(cart.total),
                            style: const TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold,
                                fontSize: 18)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed:
                            cart.items.isEmpty ? null : () => _checkout(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: const Text('Checkout'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
