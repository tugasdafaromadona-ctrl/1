import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/format.dart';
import '../../data/cart.dart';
import '../../data/datasources/database_helper.dart';
import '../../data/models/product_model.dart';
import '../../providers/auth_provider.dart';
import 'cart_screen.dart';
import 'login_screen.dart';
import 'product_detail_screen.dart';

const categories = ['Semua', 'Lari', 'Kasual', 'Basket'];

IconData categoryIcon(String c) {
  switch (c) {
    case 'Lari':
      return Icons.directions_run;
    case 'Basket':
      return Icons.sports_basketball;
    default:
      return Icons.directions_walk;
  }
}

/// Gambar placeholder produk: gradien biru + ikon kategori.
class ProductThumb extends StatelessWidget {
  final ProductModel product;
  final double iconSize;
  const ProductThumb(this.product, {super.key, this.iconSize = 56});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1E4FA3), Color(0xFF0B0E14)],
        ),
      ),
      child: Center(
        child: Icon(categoryIcon(product.category),
            size: iconSize, color: Colors.white70),
      ),
    );
  }
}

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  List<ProductModel> _products = [];
  bool _loading = true;
  String _query = '';
  String _category = 'Semua';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rows = await DatabaseHelper.instance
        .getProducts(query: _query, category: _category);
    if (!mounted) return;
    setState(() {
      _products = rows;
      _loading = false;
    });
  }

  void _logout() {
    context.read<AuthProvider>().logout();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(
        title: Text(
          auth.isAuthenticated
              ? 'StepUp • ${auth.user!.username}'
              : 'StepUp • Tamu',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        actions: [
          ListenableBuilder(
            listenable: Cart.instance,
            builder: (context, _) => IconButton(
              icon: Badge(
                isLabelVisible: Cart.instance.count > 0,
                label: Text('${Cart.instance.count}'),
                child: const Icon(Icons.shopping_bag_outlined),
              ),
              onPressed: () async {
                await Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const CartScreen()));
                _load(); // stok bisa berubah setelah checkout
              },
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Keluar',
            onPressed: _logout,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
            child: TextField(
              onChanged: (v) {
                _query = v;
                _load();
              },
              decoration: InputDecoration(
                hintText: 'Cari sneaker atau brand...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: AppColors.card,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                for (final c in categories)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(c),
                      selected: _category == c,
                      selectedColor: AppColors.primary,
                      onSelected: (_) {
                        _category = c;
                        _load();
                      },
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _products.isEmpty
                    ? const Center(child: Text('Sneaker tidak ditemukan'))
                    : GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          childAspectRatio: 0.68,
                        ),
                        itemCount: _products.length,
                        itemBuilder: (_, i) => _ProductCard(
                          _products[i],
                          onTap: () async {
                            await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => ProductDetailScreen(
                                        product: _products[i])));
                            _load(); // stok bisa berubah setelah belanja
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final ProductModel p;
  final VoidCallback onTap;
  const _ProductCard(this.p, {required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Card(
        color: AppColors.card,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: ProductThumb(p)),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.brand.toUpperCase(),
                      style: const TextStyle(
                          fontSize: 10,
                          letterSpacing: 1.2,
                          color: AppColors.primary)),
                  Text(p.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text(rupiah(p.price),
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 13)),
                  Text(p.stock > 0 ? 'Stok: ${p.stock}' : 'Stok habis',
                      style: TextStyle(
                          fontSize: 11,
                          color: p.stock > 0
                              ? AppColors.textSecondary
                              : AppColors.danger)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
