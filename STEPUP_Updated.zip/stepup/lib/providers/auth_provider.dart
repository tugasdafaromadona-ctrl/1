import 'package:flutter/foundation.dart';
import '../data/cart.dart';
import '../data/datasources/database_helper.dart';
import '../data/models/user_model.dart';

/// Kode rahasia yang harus diisi untuk mendaftar sebagai admin.
const adminRegistrationCode = 'STEPUP-ADMIN';

class AuthProvider extends ChangeNotifier {
  UserModel? _user;
  bool _isLoading = false;

  UserModel? get user => _user;
  bool get isAuthenticated => _user != null;
  bool get isAdmin => _user?.isAdmin ?? false;
  bool get isLoading => _isLoading;

  void continueAsGuest() {
    _user = null;
    Cart.instance.reset();
    notifyListeners();
  }

  /// Login sesuai peran yang dipilih ('admin' atau 'customer').
  /// Mengembalikan pesan error, atau null jika berhasil.
  Future<String?> login(String username, String password,
      {required String role}) async {
    _isLoading = true;
    notifyListeners();
    final found = await DatabaseHelper.instance.login(username, password);
    String? error;
    if (found == null) {
      error = 'Login gagal. Cek username dan password.';
    } else if (role == 'admin' && !found.isAdmin) {
      error = 'Akun ini bukan akun admin. Pilih "Pelanggan" untuk masuk.';
    } else if (role == 'customer' && found.isAdmin) {
      error = 'Akun ini adalah akun admin. Pilih "Admin" untuk masuk.';
    }
    if (error == null) {
      _user = found;
      if (found!.isAdmin) {
        Cart.instance.reset();
      } else {
        await Cart.instance.load(found.id);
      }
    } else {
      _user = null;
    }
    _isLoading = false;
    notifyListeners();
    return error;
  }

  /// Daftar sebagai admin atau pelanggan lalu langsung login.
  /// Mengembalikan pesan error, atau null jika berhasil.
  Future<String?> register(String username, String password,
      {required String role, String adminCode = ''}) async {
    if (role == 'admin' && adminCode.trim() != adminRegistrationCode) {
      return 'Kode admin salah.';
    }
    final ok = await DatabaseHelper.instance
        .register(username, password, role: role);
    if (!ok) return 'Username sudah dipakai, coba yang lain.';
    return login(username, password, role: role);
  }

  void logout() {
    _user = null;
    Cart.instance.reset();
    notifyListeners();
  }
}
