import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stepup_store/data/cart.dart';
import 'package:stepup_store/data/datasources/database_helper.dart';
import 'package:stepup_store/data/models/user_model.dart';
import 'package:stepup_store/providers/auth_provider.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    DatabaseHelper.instance.resetForTest();
    Cart.instance.reset();
  });

  test('UserModel fromMap, toMap, dan role admin', () {
    final u = UserModel.fromMap(
        {'id': 1, 'username': 'admin', 'password': 'admin123', 'role': 'admin'});
    expect(u.isAdmin, true);
    expect(u.toMap()['username'], 'admin');
  });

  test('state tamu: tidak terautentikasi dan bukan admin', () {
    final auth = AuthProvider()..continueAsGuest();
    expect(auth.isAuthenticated, false);
    expect(auth.isAdmin, false);
  });

  test('1 & 3: daftar admin (butuh kode) lalu login admin', () async {
    final auth = AuthProvider();
    expect(
        await auth.register('dosen', 'pass1', role: 'admin', adminCode: 'salah'),
        isNotNull);
    expect(
        await auth.register('dosen', 'pass1',
            role: 'admin', adminCode: adminRegistrationCode),
        isNull);
    expect(auth.isAdmin, true);
    auth.logout();
    expect(await auth.login('dosen', 'pass1', role: 'admin'), isNull);
    expect(await auth.login('dosen', 'pass1', role: 'customer'), isNotNull);
  });

  test('2 & 4: daftar pelanggan lalu login pelanggan', () async {
    final auth = AuthProvider();
    expect(await auth.register('budi', '1234', role: 'customer'), isNull);
    expect(auth.isAuthenticated, true);
    expect(auth.isAdmin, false);
    expect(await auth.register('budi', '1234', role: 'customer'), isNotNull);
    auth.logout();
    expect(await auth.login('budi', '1234', role: 'admin'), isNotNull);
    expect(await auth.login('budi', '1234', role: 'customer'), isNull);
  });

  test('5: admin menambah barang baru dan update stok barang lama', () async {
    final db = DatabaseHelper.instance;
    final before = (await db.getProducts()).length;
    final p = (await db.getProducts()).first;
    await db.updateStock(p.id, 99);
    expect((await db.getProduct(p.id))!.stock, 99);

    await db.saveProduct(p.copyWith(stock: 5).copyWith());
    expect((await db.getProducts()).length, before);
  });

  test('6-10: keranjang menambah/mengurangi/hapus dan stok ikut berubah',
      () async {
    final auth = AuthProvider();
    await auth.register('siti', '1234', role: 'customer');
    final db = DatabaseHelper.instance;
    final cart = Cart.instance;
    final p = (await db.getProducts()).first;
    final stock0 = p.stock;

    // 6 & 10: masukkan ke keranjang -> stok berkurang 1
    expect(await cart.add(p, 42), isNull);
    expect(cart.count, 1);
    expect((await db.getProduct(p.id))!.stock, stock0 - 1);

    // 7 & 10: tambah jumlah -> stok berkurang lagi
    await cart.add(p, 42);
    expect(cart.count, 2);
    expect((await db.getProduct(p.id))!.stock, stock0 - 2);

    // ukuran berbeda = baris berbeda
    await cart.add(p, 40);
    expect(cart.items.length, 2);
    expect((await db.getProduct(p.id))!.stock, stock0 - 3);

    // 8: kurangi jumlah -> stok kembali 1
    await cart.decrease(cart.items.firstWhere((i) => i.size == 42));
    expect(cart.count, 2);
    expect((await db.getProduct(p.id))!.stock, stock0 - 2);

    // 9: hapus barang -> stok kembali penuh
    await cart.remove(cart.items.firstWhere((i) => i.size == 42));
    await cart.remove(cart.items.firstWhere((i) => i.size == 40));
    expect(cart.items, isEmpty);
    expect((await db.getProduct(p.id))!.stock, stock0);
  });

  test('stok habis: tidak bisa menambah lagi', () async {
    final auth = AuthProvider();
    await auth.register('andi', '1234', role: 'customer');
    final db = DatabaseHelper.instance;
    final p = (await db.getProducts()).first;
    await db.updateStock(p.id, 1);
    expect(await Cart.instance.add(p, 41), isNull);
    expect(await Cart.instance.add(p, 41), isNotNull);
    expect((await db.getProduct(p.id))!.stock, 0);
  });

  test('keranjang tersimpan per pelanggan dan checkout tidak mengurangi stok lagi',
      () async {
    final auth = AuthProvider();
    final db = DatabaseHelper.instance;
    await auth.register('rina', '1234', role: 'customer');
    final p = (await db.getProducts()).first;
    final stock0 = p.stock;
    await Cart.instance.add(p, 42);

    auth.logout();
    expect(Cart.instance.items, isEmpty);
    await auth.login('rina', '1234', role: 'customer');
    expect(Cart.instance.count, 1); // keranjang dimuat kembali

    final id = await Cart.instance.checkout('rina');
    expect(id, isNotNull);
    expect(Cart.instance.items, isEmpty);
    expect((await db.getProduct(p.id))!.stock, stock0 - 1);
    expect((await db.getOrdersWithItems()).length, 1);
  });
}
