# STEPUP Sneaker Store

Aplikasi Flutter toko sepatu sneaker (admin & pelanggan), berjalan di Chrome.

## Menjalankan di Chrome
Buka terminal pada folder yang berisi `pubspec.yaml`, lalu jalankan:

```powershell
flutter create --platforms=web .
flutter pub get
flutter run -d chrome
```

Jika `flutter create` bertanya soal menimpa file, jangan timpa folder `lib/`.

Menjalankan test:

```powershell
flutter test
```

## Fitur sesuai tugas
| No | Fitur | Di mana |
|----|-------|---------|
| 1 | Register admin | Login -> pilih **Admin** -> *Belum punya akun? Daftar* (butuh kode admin `STEPUP-ADMIN`) |
| 2 | Register customer | Login -> pilih **Pelanggan** -> *Belum punya akun? Daftar* |
| 3 | Login admin | Pilih **Admin** lalu Masuk (akun demo: `admin` / `admin123`) |
| 4 | Login pelanggan | Pilih **Pelanggan** lalu Masuk |
| 5 | Admin tambah barang baru & update stok | Dashboard admin: tombol **+ Produk** dan ikon **inventori** (update stok) pada tiap produk |
| 6 | Customer masukkan barang ke keranjang | Detail produk -> pilih ukuran -> *Tambah ke Keranjang* |
| 7 | Tambah jumlah di keranjang | Tombol **+** di halaman Keranjang |
| 8 | Kurangi jumlah di keranjang | Tombol **-** di halaman Keranjang |
| 9 | Hapus barang di keranjang | Ikon tempat sampah di halaman Keranjang |
| 10 | Stok berkurang saat masuk/tambah keranjang, terlihat customer & admin | Stok tampil di katalog, detail, keranjang (customer) dan daftar produk (admin) |

## Aturan stok
- Barang masuk keranjang atau jumlahnya ditambah -> stok produk **berkurang 1**.
- Jumlah dikurangi atau barang dihapus dari keranjang -> stok **dikembalikan**.
- Checkout -> keranjang menjadi pesanan; stok tidak dikurangi lagi (sudah dikurangi sebelumnya).
- Keranjang disimpan per pelanggan, jadi tetap ada setelah logout/login ulang.
- Admin melihat stok terbaru lewat tombol **Muat ulang** di dashboard.

## Catatan
Penyimpanan memakai `shared_preferences` (lokal di browser), bukan server online.
Karena itu admin dan pelanggan sebaiknya diuji di browser yang sama.
